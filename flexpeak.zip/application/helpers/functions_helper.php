<?php
    function msgErro($msg){
        return "<div class=\"alert alert-danger\">$msg</div>";
    }
    function msgSucesso($msg){
        return "<div class=\"alert alert-success\">$msg</div>";
    }

?>